import logo from './logo.svg';
import './App.css';
import { Booking } from './Components/Booking';

function App() {
  return (
    <div className="App">
      <Booking/>
    </div>
  );
}

export default App;
