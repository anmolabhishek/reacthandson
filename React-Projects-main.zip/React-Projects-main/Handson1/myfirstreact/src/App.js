//import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <h1> welcome to first session of React</h1>
  );
}

export default App;
