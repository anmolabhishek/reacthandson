import logo from './logo.svg';
import './App.css';
import { ComplaintRegister } from './Components/ComplaintRegister';

function App() {
  return (
    <div className="App">
      <ComplaintRegister/>
    </div>
  );
}

export default App;
