import React,{Component} from 'react'
export class About extends Component{
    render(){

        return(
        <div className="App">
        <h3>Welcome to the About Page of Student Management Portal</h3>
        </div>
        );
    }
}

