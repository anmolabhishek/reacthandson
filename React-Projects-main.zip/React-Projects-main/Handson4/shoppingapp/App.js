import logo from './logo.svg';
import './App.css';
import {OnlineShopping} from '../src/Components/OnlineShopping';
import {Cart} from '../src/Components/Cart';


function App() {
  return (
    <div className="App">
      <OnlineShopping/>
      <Cart/>
      
    </div>
  );
}

export default App;
